# IMPULSA360 — De la idea al éxito

Sitio estático listo para GitHub Pages. Proyecto D.O.

## Publicar con GitHub Pages

1. En GitHub, crea un repositorio público llamado `IMPULSA360` (o el nombre que prefieras).
2. Abre el repositorio y selecciona **Add file → Upload files**.
3. **Descomprime** el ZIP de este proyecto en tu computador. Arrastra a GitHub los archivos `index.html`, `README.md`, `.nojekyll` y la carpeta `assets` (con sus dos archivos). Si el sistema no muestra `.nojekyll`, puedes omitirlo.
4. Haz clic en **Commit changes**.
5. En el repositorio abre **Settings → Pages**. En **Build and deployment**, elige **Deploy from a branch**. Selecciona la rama `main` y la carpeta **/(root)**, y pulsa **Save**.
6. Cuando GitHub termine de publicar, abre `https://TU-USUARIO.github.io/IMPULSA360/` (sustituye usuario y nombre del repositorio según corresponda).

**Importante:** No subas el ZIP sin descomprimir esperando que GitHub Pages lo publique automáticamente. `index.html` debe quedar en la raíz del repositorio.

## Archivos

- `index.html`: estructura de la página.
- `assets/styles.css`: estilos.
- `assets/app.js`: funcionamiento.
- `.nojekyll`: desactiva el procesamiento Jekyll en GitHub Pages.

## Alcance

Esta versión funciona con HTML, CSS y JavaScript en el navegador. Incluye academia, diagnóstico orientativo basado en reglas, estrategias y calculadora. **No incluye conexión a IA, datos de mercado en tiempo real ni cuentas de usuario.** No se requiere servidor para esta versión.
